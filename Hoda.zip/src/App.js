import React from 'react';
import Body from './Component/Body'
import Footer from './Component/Footer'




function App() {
  return (
   <>
   <Body/>
   <Footer/>
   </>
  );
}

export default App;

import React,{ Component } from "react";
 import img from '../image/girl.jpeg';
 
export default class Content extends Component{
    render(){
        return(
           <div>
               <div class="all">
               <div class="left">
   
   <div>
   <div class="container"><img src={img} /> 
       <div class="bottomleft">Hoda Elfalal</div>
   </div>
<div class="words">
   <div class="one">
       
   <span class="glyphicon">
       <p>Desiner</p>
    </span>
   
   <span class="glyphicon glyphicon-home"><p> Egypt,Menofia</p></span>
   <span class="glyphicon glyphicon-envelope"><p> hodaelfalal@gmail.com</p> </span>
   <span class="glyphicon glyphicon-earphone"><p> 0125453651</p></span>
</div>
<div id="line"></div>
<div>
    
   <span class="glyphicon glyphicon-paperclip"></span><h id="word">Skills</h>
   <p>Art 95%</p>
   
   <p>Adobe Photoshop 90%</p>
   <p>Illustrator 75%</p>
   <p>Media 60%</p>
</div>

<div>
    <div id="line"></div>
   
   <span class="glyphicon glyphicon-globe"></span><h id="word">Languages</h>
   <p>English 80%</p>
   <p>French 60%</p>
   <p>Japanese 30%</p>
</div>
</div> 
</div>
</div>
               </div>

               <div class="right">
    <div class="experince">
        <span class="glyphicon glyphicon-tasks"></span>
        <h id="head">Work Experince</h>
        <h id="top">ART/ Self study</h>
        <span class="glyphicon glyphicon-calendar"> <span>Forever</span></span>
        <p id="word">this is what i love the most andi do it well and always strive to improve</p>
        <div id="line"></div>
        <h id="top">Graphic Designer/ Multimedia team leader (icpc)</h>
        <span class="glyphicon glyphicon-calendar"> <span>2019 - Current</span></span>
        <p id="word">this is what i love the most andi do it well and always strive to improve</p>
        <div id="line"></div>
        <h id="top">Front End Deveioper/ Elzero Chanel </h>
        <span class="glyphicon glyphicon-calendar"> <span>2017 - 2019</span></span>
        <p id="word">this is what i love the most andi do it well and always strive to improve</p>

    </div>
    <div id="line1"></div>
    <div class="education">
        <span class="glyphicon glyphicon-certificate"> <h id="head">Education</h></span>
        
        <h id="top">W3Schools.com</h>
        <span class="glyphicon glyphicon-calendar"> <span>2017 - 2019</span></span>
        <p id="word">Web Development! All i need to know in one place.</p>
        <div id="line"></div>
        <h id="top">London School</h>
        <span class="glyphicon glyphicon-calendar"> <span>2018 - 2020</span></span>
        <p id="word">Master Degree.</p>
        <div id="line"></div>
        <h id="top">School of coding</h>
        <span class="glyphicon glyphicon-calendar"> <span>2019 - 2021</span></span>
        <p id="word">Bachelor Degree.</p>
    </div>
           </div>
           </div>
        );
    }
}
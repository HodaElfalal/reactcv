import React,{ Component } from "react";
 
export default class Content extends Component{
    render(){
        return(
           <div>
               <div id="footer">
    <p>Footer</p>
</div>
           </div>
        );
    }
}